# Earth Engine STAC Catalog Tools

This directory contains Python scripts to help load and work with the Earth Engine STAC (SpatioTemporal Asset Catalog) metadata.

For more details about the EE STAC catalog see the main README at
https://github.com/google/earthengine-catalog